<!DOCTYPE html>
<html lang="es">
<head>
    <title>PPCR (Placa de Piezas y Componentes de Recambio)</title>
</head>
<body>
<?php
include_once '../connection/data.php';
$contacts = new Contacts();
$date = $contacts->getDatePending();
//$date = date_create($date[0][0]);
	var_dump($date);
?>
    
</body>
</html>